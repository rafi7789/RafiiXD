# GAFI

# DOWNLOAD APK TERMUX 
Klick di 👉[SINI](https://f-droid.org/repo/com.termux_117.apk), Untuk Mendownload Nya Buka Aplikasi Ketikan Perintah Dibawah .
# INSTALL

```````
rm -rf GAFI
git clone https://github.com/Bajingan-Z/GAFI
cd GAFI
git pull
python gafiku.py
